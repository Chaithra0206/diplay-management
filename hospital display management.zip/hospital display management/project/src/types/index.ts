export interface Patient {
  id: string;
  tokenNumber: string;
  initials: string;
  department: string;
  status: 'waiting' | 'in-progress' | 'completed';
  estimatedWaitTime: number;
  priority: 'normal' | 'urgent' | 'emergency';
  checkedInAt: Date;
}

export interface Department {
  id: string;
  name: string;
  code: string;
  currentToken: string;
  totalPatientsToday: number;
  averageWaitTime: number;
  activeStaff: number;
  status: 'active' | 'inactive' | 'maintenance';
}

export interface InventoryItem {
  id: string;
  name: string;
  category: string;
  currentStock: number;
  minThreshold: number;
  maxCapacity: number;
  unit: string;
  lastUpdated: Date;
  supplier: string;
  expiryDate?: Date;
}

export interface EmergencyAlert {
  id: string;
  type: 'code-blue' | 'code-red' | 'fire' | 'evacuation' | 'security';
  message: string;
  location: string;
  timestamp: Date;
  isActive: boolean;
  priority: 'high' | 'critical';
}

export interface StaffMember {
  id: string;
  name: string;
  role: string;
  department: string;
  status: 'available' | 'busy' | 'break' | 'off-duty';
}