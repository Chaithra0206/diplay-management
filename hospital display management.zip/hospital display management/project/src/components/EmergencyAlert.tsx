import React from 'react';
import { AlertTriangle, X, Shield, Flame, Users } from 'lucide-react';
import { EmergencyAlert as EmergencyAlertType } from '../types';

interface EmergencyAlertProps {
  alert: EmergencyAlertType;
  onDismiss: (alertId: string) => void;
}

const EmergencyAlert: React.FC<EmergencyAlertProps> = ({ alert, onDismiss }) => {
  const getAlertIcon = () => {
    switch (alert.type) {
      case 'code-blue':
        return <Shield className="w-6 h-6" />;
      case 'code-red':
        return <AlertTriangle className="w-6 h-6" />;
      case 'fire':
        return <Flame className="w-6 h-6" />;
      case 'evacuation':
        return <Users className="w-6 h-6" />;
      default:
        return <AlertTriangle className="w-6 h-6" />;
    }
  };

  const getAlertColors = () => {
    switch (alert.priority) {
      case 'critical':
        return 'bg-red-600 text-white border-red-700';
      case 'high':
        return 'bg-orange-500 text-white border-orange-600';
      default:
        return 'bg-yellow-500 text-black border-yellow-600';
    }
  };

  return (
    <div className={`fixed top-4 right-4 z-50 p-4 rounded-lg border-2 shadow-lg animate-pulse ${getAlertColors()}`}>
      <div className="flex items-start justify-between">
        <div className="flex items-center space-x-3">
          {getAlertIcon()}
          <div>
            <h3 className="font-bold text-lg uppercase tracking-wide">
              {alert.type.replace('-', ' ')}
            </h3>
            <p className="font-medium">{alert.message}</p>
            <p className="text-sm opacity-90">{alert.location}</p>
            <p className="text-xs opacity-75">
              {alert.timestamp.toLocaleTimeString()}
            </p>
          </div>
        </div>
        <button
          onClick={() => onDismiss(alert.id)}
          className="ml-4 hover:opacity-70"
        >
          <X className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};

export default EmergencyAlert;