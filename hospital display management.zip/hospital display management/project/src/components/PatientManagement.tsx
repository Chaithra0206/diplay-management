import React, { useState } from 'react';
import { Plus, Phone, SkipForward, Trash2, CheckCircle, User, AlertCircle } from 'lucide-react';
import { Patient, Department } from '../types';

interface PatientManagementProps {
  patients: Patient[];
  departments: Department[];
  selectedDepartment: string;
  onAddPatient: (department: string, initials: string, priority: 'normal' | 'urgent' | 'emergency') => void;
  onCallNextToken: (department: string) => void;
  onSkipPatient: (patientId: string) => void;
  onRemovePatient: (patientId: string) => void;
  onCompletePatient: (patientId: string) => void;
  onCallPatient: (patientId: string) => void;
}

const PatientManagement: React.FC<PatientManagementProps> = ({
  patients,
  departments,
  selectedDepartment,
  onAddPatient,
  onCallNextToken,
  onSkipPatient,
  onRemovePatient,
  onCompletePatient,
  onCallPatient
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newPatientInitials, setNewPatientInitials] = useState('');
  const [newPatientPriority, setNewPatientPriority] = useState<'normal' | 'urgent' | 'emergency'>('normal');

  const departmentPatients = patients
    .filter(p => p.department === selectedDepartment)
    .sort((a, b) => {
      // Priority patients first
      if (a.priority === 'emergency' && b.priority !== 'emergency') return -1;
      if (b.priority === 'emergency' && a.priority !== 'emergency') return 1;
      if (a.priority === 'urgent' && b.priority === 'normal') return -1;
      if (b.priority === 'urgent' && a.priority === 'normal') return 1;
      
      // Then by token number
      return parseInt(a.tokenNumber.split('-')[1]) - parseInt(b.tokenNumber.split('-')[1]);
    });

  const waitingPatients = departmentPatients.filter(p => p.status === 'waiting');
  const inProgressPatients = departmentPatients.filter(p => p.status === 'in-progress');

  const handleAddPatient = () => {
    if (newPatientInitials.trim().length >= 2) {
      onAddPatient(selectedDepartment, newPatientInitials.trim(), newPatientPriority);
      setNewPatientInitials('');
      setNewPatientPriority('normal');
      setShowAddModal(false);
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'emergency': return 'text-red-600 bg-red-100';
      case 'urgent': return 'text-orange-600 bg-orange-100';
      default: return 'text-blue-600 bg-blue-100';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'emergency': return <AlertCircle className="w-4 h-4" />;
      case 'urgent': return <AlertCircle className="w-4 h-4" />;
      default: return <User className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Quick Actions */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Patient Management</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <button
            onClick={() => setShowAddModal(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-3 rounded-lg flex items-center justify-center space-x-2 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Add Patient</span>
          </button>
          <button
            onClick={() => onCallNextToken(selectedDepartment)}
            disabled={waitingPatients.length === 0}
            className="bg-green-600 hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white px-4 py-3 rounded-lg flex items-center justify-center space-x-2 transition-colors"
          >
            <Phone className="w-4 h-4" />
            <span>Call Next</span>
          </button>
          <button
            onClick={() => {
              const nextPatient = waitingPatients[0];
              if (nextPatient) onSkipPatient(nextPatient.id);
            }}
            disabled={waitingPatients.length === 0}
            className="bg-orange-600 hover:bg-orange-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white px-4 py-3 rounded-lg flex items-center justify-center space-x-2 transition-colors"
          >
            <SkipForward className="w-4 h-4" />
            <span>Skip Next</span>
          </button>
          <button
            onClick={() => {
              const currentPatient = inProgressPatients[0];
              if (currentPatient) onCompletePatient(currentPatient.id);
            }}
            disabled={inProgressPatients.length === 0}
            className="bg-purple-600 hover:bg-purple-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white px-4 py-3 rounded-lg flex items-center justify-center space-x-2 transition-colors"
          >
            <CheckCircle className="w-4 h-4" />
            <span>Complete</span>
          </button>
        </div>
      </div>

      {/* Patient Queue Management */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">
          {departments.find(d => d.code === selectedDepartment)?.name} Queue
        </h3>

        {/* In Progress Patients */}
        {inProgressPatients.length > 0 && (
          <div className="mb-6">
            <h4 className="text-sm font-semibold text-gray-600 mb-3 flex items-center">
              <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></div>
              Currently Being Served
            </h4>
            <div className="space-y-2">
              {inProgressPatients.map(patient => (
                <div key={patient.id} className="flex items-center justify-between p-4 bg-green-50 rounded-lg border-l-4 border-green-500">
                  <div className="flex items-center space-x-3">
                    <div className={`px-2 py-1 rounded-full text-xs font-medium flex items-center space-x-1 ${getPriorityColor(patient.priority)}`}>
                      {getPriorityIcon(patient.priority)}
                      <span>{patient.priority.toUpperCase()}</span>
                    </div>
                    <div>
                      <span className="font-mono font-bold text-green-800">{patient.tokenNumber}</span>
                      <span className="text-sm text-green-600 ml-2">({patient.initials})</span>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => onCompletePatient(patient.id)}
                      className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded text-sm flex items-center space-x-1"
                    >
                      <CheckCircle className="w-3 h-3" />
                      <span>Complete</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Waiting Queue */}
        <div>
          <h4 className="text-sm font-semibold text-gray-600 mb-3 flex items-center">
            <div className="w-2 h-2 bg-blue-500 rounded-full mr-2"></div>
            Waiting Queue ({waitingPatients.length})
          </h4>
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {waitingPatients.map((patient, index) => (
              <div key={patient.id} className={`flex items-center justify-between p-4 rounded-lg ${
                index < 3 ? 'bg-blue-50 border-l-4 border-blue-500' : 'bg-gray-50'
              }`}>
                <div className="flex items-center space-x-3">
                  <div className="text-xs font-mono text-gray-500 w-8">
                    #{index + 1}
                  </div>
                  <div className={`px-2 py-1 rounded-full text-xs font-medium flex items-center space-x-1 ${getPriorityColor(patient.priority)}`}>
                    {getPriorityIcon(patient.priority)}
                    <span>{patient.priority.toUpperCase()}</span>
                  </div>
                  <div>
                    <span className="font-mono font-bold text-gray-800">{patient.tokenNumber}</span>
                    <span className="text-sm text-gray-600 ml-2">({patient.initials})</span>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-xs text-gray-500">~{patient.estimatedWaitTime}m</span>
                  <div className="flex space-x-1">
                    <button
                      onClick={() => onCallPatient(patient.id)}
                      className="bg-blue-600 hover:bg-blue-700 text-white px-2 py-1 rounded text-xs flex items-center space-x-1"
                      title="Call Patient"
                    >
                      <Phone className="w-3 h-3" />
                    </button>
                    <button
                      onClick={() => onSkipPatient(patient.id)}
                      className="bg-orange-600 hover:bg-orange-700 text-white px-2 py-1 rounded text-xs flex items-center space-x-1"
                      title="Skip Patient"
                    >
                      <SkipForward className="w-3 h-3" />
                    </button>
                    <button
                      onClick={() => onRemovePatient(patient.id)}
                      className="bg-red-600 hover:bg-red-700 text-white px-2 py-1 rounded text-xs flex items-center space-x-1"
                      title="Remove Patient"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
            {waitingPatients.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <User className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>No patients in waiting queue</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Add Patient Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <h3 className="text-lg font-bold text-gray-800 mb-4">Add New Patient</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Patient Initials
                </label>
                <input
                  type="text"
                  value={newPatientInitials}
                  onChange={(e) => setNewPatientInitials(e.target.value.toUpperCase())}
                  placeholder="e.g., AB"
                  maxLength={3}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Priority Level
                </label>
                <select
                  value={newPatientPriority}
                  onChange={(e) => setNewPatientPriority(e.target.value as 'normal' | 'urgent' | 'emergency')}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="normal">Normal</option>
                  <option value="urgent">Urgent</option>
                  <option value="emergency">Emergency</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Department
                </label>
                <input
                  type="text"
                  value={departments.find(d => d.code === selectedDepartment)?.name || ''}
                  disabled
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 bg-gray-100 text-gray-600"
                />
              </div>
            </div>
            <div className="mt-6 flex space-x-3">
              <button
                onClick={() => setShowAddModal(false)}
                className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleAddPatient}
                disabled={newPatientInitials.trim().length < 2}
                className="flex-1 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white px-4 py-2 rounded-lg transition-colors"
              >
                Add Patient
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PatientManagement;