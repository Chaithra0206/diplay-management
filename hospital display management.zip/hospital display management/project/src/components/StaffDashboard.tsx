import React, { useState } from 'react';
import { Bell, Settings, RefreshCw } from 'lucide-react';
import DepartmentOverview from './DepartmentOverview';
import PatientManagement from './PatientManagement';
import InventoryMonitor from './InventoryMonitor';
import EmergencyAlert from './EmergencyAlert';
import { useRealTimeData } from '../hooks/useRealTimeData';

const StaffDashboard: React.FC = () => {
  const { 
    patients, 
    departments, 
    inventory, 
    alerts, 
    addEmergencyAlert, 
    dismissAlert,
    addPatient,
    callNextToken,
    skipPatient,
    removePatient,
    completePatient,
    callPatient
  } = useRealTimeData();
  
  const [showEmergencyModal, setShowEmergencyModal] = useState(false);
  const [selectedDepartment, setSelectedDepartment] = useState('OT');

  const handleEmergencyAlert = (type: string) => {
    const alertTypes = {
      'code-blue': {
        type: 'code-blue' as const,
        message: 'Medical Emergency - Immediate Response Required',
        location: 'Emergency Department',
        priority: 'critical' as const,
        isActive: true
      },
      'code-red': {
        type: 'code-red' as const,
        message: 'Fire Emergency - Evacuation Procedures Active',
        location: 'Building Block A',
        priority: 'critical' as const,
        isActive: true
      },
      'fire': {
        type: 'fire' as const,
        message: 'Fire Detected - Emergency Services Notified',
        location: 'Cafeteria Area',
        priority: 'high' as const,
        isActive: true
      }
    };

    const alertData = alertTypes[type as keyof typeof alertTypes];
    if (alertData) {
      addEmergencyAlert(alertData);
      setShowEmergencyModal(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Emergency Alerts */}
      {alerts.map(alert => (
        <EmergencyAlert 
          key={alert.id} 
          alert={alert} 
          onDismiss={dismissAlert} 
        />
      ))}

      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Wenlock Hospital</h1>
              <p className="text-sm text-gray-600">Staff Management Dashboard</p>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setShowEmergencyModal(true)}
                className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors"
              >
                <Bell className="w-4 h-4" />
                <span>Emergency Alert</span>
              </button>
              <button className="p-2 text-gray-600 hover:text-gray-900 rounded-lg hover:bg-gray-100">
                <RefreshCw className="w-5 h-5" />
              </button>
              <button className="p-2 text-gray-600 hover:text-gray-900 rounded-lg hover:bg-gray-100">
                <Settings className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Department Overview */}
        <DepartmentOverview departments={departments} />

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
          {/* Patient Management */}
          <div className="xl:col-span-2 space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold text-gray-800">Patient Management</h2>
              <select 
                value={selectedDepartment}
                onChange={(e) => setSelectedDepartment(e.target.value)}
                className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {departments.map(dept => (
                  <option key={dept.id} value={dept.code}>{dept.name}</option>
                ))}
              </select>
            </div>
            
            <PatientManagement
              patients={patients}
              departments={departments}
              selectedDepartment={selectedDepartment}
              onAddPatient={addPatient}
              onCallNextToken={callNextToken}
              onSkipPatient={skipPatient}
              onRemovePatient={removePatient}
              onCompletePatient={completePatient}
              onCallPatient={callPatient}
            />
          </div>

          {/* Inventory Monitor */}
          <div>
            <InventoryMonitor inventory={inventory} />
          </div>
        </div>
      </main>

      {/* Emergency Alert Modal */}
      {showEmergencyModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <h3 className="text-lg font-bold text-gray-800 mb-4">Emergency Alert</h3>
            <p className="text-gray-600 mb-6">Select the type of emergency alert to broadcast:</p>
            <div className="space-y-3">
              <button
                onClick={() => handleEmergencyAlert('code-blue')}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-3 rounded-lg transition-colors"
              >
                Code Blue - Medical Emergency
              </button>
              <button
                onClick={() => handleEmergencyAlert('code-red')}
                className="w-full bg-red-600 hover:bg-red-700 text-white px-4 py-3 rounded-lg transition-colors"
              >
                Code Red - Fire Emergency
              </button>
              <button
                onClick={() => handleEmergencyAlert('fire')}
                className="w-full bg-orange-600 hover:bg-orange-700 text-white px-4 py-3 rounded-lg transition-colors"
              >
                Fire Alert
              </button>
            </div>
            <div className="mt-6 flex space-x-3">
              <button
                onClick={() => setShowEmergencyModal(false)}
                className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2 rounded-lg transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StaffDashboard;