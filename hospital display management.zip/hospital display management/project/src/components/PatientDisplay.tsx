import React, { useState, useEffect } from 'react';
import { Clock, Users, ArrowRight, Volume2 } from 'lucide-react';
import { Patient, Department } from '../types';

interface PatientDisplayProps {
  patients: Patient[];
  departments: Department[];
}

const PatientDisplay: React.FC<PatientDisplayProps> = ({ patients, departments }) => {
  const [recentlyCalledTokens, setRecentlyCalledTokens] = useState<string[]>([]);
  const [lastCalledToken, setLastCalledToken] = useState<string>('');

  // Track when tokens are called to show visual/audio feedback
  useEffect(() => {
    departments.forEach(dept => {
      if (dept.currentToken !== lastCalledToken && dept.currentToken) {
        setLastCalledToken(dept.currentToken);
        setRecentlyCalledTokens(prev => [dept.currentToken, ...prev.slice(0, 4)]);
        
        // Simulate audio announcement
        console.log(`🔊 NOW CALLING: ${dept.currentToken} to ${dept.name}`);
        
        // Remove from recent calls after 30 seconds
        setTimeout(() => {
          setRecentlyCalledTokens(prev => prev.filter(token => token !== dept.currentToken));
        }, 30000);
      }
    });
  }, [departments, lastCalledToken]);

  const getNextPatients = (deptCode: string, count: number = 3) => {
    return patients
      .filter(p => p.department === deptCode && p.status === 'waiting')
      .sort((a, b) => {
        // Priority patients first
        if (a.priority === 'emergency' && b.priority !== 'emergency') return -1;
        if (b.priority === 'emergency' && a.priority !== 'emergency') return 1;
        if (a.priority === 'urgent' && b.priority === 'normal') return -1;
        if (b.priority === 'urgent' && a.priority === 'normal') return 1;
        
        // Then by token number
        return parseInt(a.tokenNumber.split('-')[1]) - parseInt(b.tokenNumber.split('-')[1]);
      })
      .slice(0, count);
  };

  const isRecentlyCalled = (token: string) => {
    return recentlyCalledTokens.includes(token);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'emergency': return 'bg-red-100 text-red-800 border-red-300';
      case 'urgent': return 'bg-orange-100 text-orange-800 border-orange-300';
      default: return 'bg-blue-100 text-blue-800 border-blue-300';
    }
  };

  return (
    <div className="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">Wenlock Hospital</h1>
          <p className="text-xl text-gray-600">Patient Information Display</p>
          <div className="text-lg text-gray-500 mt-2">
            {new Date().toLocaleDateString()} • {new Date().toLocaleTimeString()}
          </div>
        </div>

        {/* Recently Called Tokens Alert */}
        {recentlyCalledTokens.length > 0 && (
          <div className="mb-8 bg-green-600 text-white rounded-2xl p-6 shadow-xl animate-pulse">
            <div className="flex items-center justify-center space-x-4">
              <Volume2 className="w-8 h-8" />
              <div className="text-center">
                <p className="text-sm opacity-90 mb-1">RECENTLY CALLED</p>
                <div className="flex flex-wrap justify-center gap-3">
                  {recentlyCalledTokens.slice(0, 3).map(token => (
                    <span key={token} className="text-2xl font-bold font-mono bg-white bg-opacity-20 px-4 py-2 rounded-lg">
                      {token}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Department Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {departments.map(dept => {
            const nextPatients = getNextPatients(dept.code);
            const waitingCount = patients.filter(p => p.department === dept.code && p.status === 'waiting').length;
            const currentPatient = patients.find(p => p.tokenNumber === dept.currentToken);
            
            return (
              <div key={dept.id} className="bg-white rounded-2xl shadow-xl p-8">
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-800">{dept.name}</h2>
                    <p className="text-gray-600">{dept.code} Department</p>
                  </div>
                  <div className={`w-4 h-4 rounded-full ${
                    dept.status === 'active' ? 'bg-green-500' : 'bg-red-500'
                  }`}></div>
                </div>

                {/* Current Token */}
                <div className={`${
                  isRecentlyCalled(dept.currentToken) 
                    ? 'bg-green-600 animate-pulse shadow-lg shadow-green-200' 
                    : 'bg-blue-600'
                } text-white rounded-xl p-6 mb-6 transition-all duration-500`}>
                  <div className="text-center">
                    <div className="flex items-center justify-center space-x-2 mb-2">
                      {isRecentlyCalled(dept.currentToken) && (
                        <Volume2 className="w-5 h-5 animate-bounce" />
                      )}
                      <p className="text-sm opacity-90">
                        {isRecentlyCalled(dept.currentToken) ? 'NOW CALLING' : 'CURRENTLY SERVING'}
                      </p>
                    </div>
                    <p className="text-4xl font-bold font-mono">{dept.currentToken}</p>
                    {currentPatient && (
                      <div className="mt-2 flex items-center justify-center space-x-2">
                        <span className="text-sm opacity-90">Patient: {currentPatient.initials}</span>
                        {currentPatient.priority !== 'normal' && (
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            currentPatient.priority === 'emergency' 
                              ? 'bg-red-500 bg-opacity-30' 
                              : 'bg-orange-500 bg-opacity-30'
                          }`}>
                            {currentPatient.priority.toUpperCase()}
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* Next in Queue */}
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-700">Next in Queue</h3>
                    <div className="flex items-center text-sm text-gray-500">
                      <Users className="w-4 h-4 mr-1" />
                      {waitingCount} waiting
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    {nextPatients.map((patient, index) => (
                      <div key={patient.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="bg-blue-100 text-blue-800 w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold">
                            {index + 1}
                          </div>
                          <div className="flex items-center space-x-2">
                            <span className="font-mono font-bold text-lg">{patient.tokenNumber}</span>
                            <span className="text-sm text-gray-600">({patient.initials})</span>
                            {patient.priority !== 'normal' && (
                              <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getPriorityColor(patient.priority)}`}>
                                {patient.priority.toUpperCase()}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center text-gray-500">
                          <Clock className="w-4 h-4 mr-1" />
                          <span className="text-sm">~{patient.estimatedWaitTime}m</span>
                        </div>
                      </div>
                    ))}
                    
                    {nextPatients.length === 0 && (
                      <div className="text-center py-8 text-gray-500">
                        <Users className="w-12 h-12 mx-auto mb-2 opacity-50" />
                        <p>No patients in queue</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Department Info */}
                <div className="border-t pt-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="text-center">
                      <p className="text-gray-500">Average Wait</p>
                      <p className="font-bold text-lg">{dept.averageWaitTime}m</p>
                    </div>
                    <div className="text-center">
                      <p className="text-gray-500">Patients Today</p>
                      <p className="font-bold text-lg">{dept.totalPatientsToday}</p>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="text-center mt-12 text-gray-500">
          <p className="text-sm">Please wait for your token number to be called</p>
          <p className="text-xs mt-1">For assistance, please contact the information desk</p>
          {recentlyCalledTokens.length > 0 && (
            <p className="text-xs mt-2 text-green-600 font-medium">
              🔊 Listen for audio announcements when your token is called
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default PatientDisplay;