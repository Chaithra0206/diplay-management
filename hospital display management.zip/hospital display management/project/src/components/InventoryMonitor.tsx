import React from 'react';
import { Package, AlertTriangle, TrendingDown, Calendar } from 'lucide-react';
import { InventoryItem } from '../types';

interface InventoryMonitorProps {
  inventory: InventoryItem[];
}

const InventoryMonitor: React.FC<InventoryMonitorProps> = ({ inventory }) => {
  const lowStockItems = inventory.filter(item => item.currentStock <= item.minThreshold);
  const criticalItems = inventory.filter(item => item.currentStock < item.minThreshold * 0.5);

  const getStockStatus = (item: InventoryItem) => {
    const percentage = (item.currentStock / item.maxCapacity) * 100;
    if (percentage <= 10) return { color: 'red', status: 'Critical' };
    if (percentage <= 25) return { color: 'orange', status: 'Low' };
    if (percentage <= 50) return { color: 'yellow', status: 'Medium' };
    return { color: 'green', status: 'Good' };
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-gray-800">Inventory Monitor</h2>
        <div className="flex space-x-2">
          {criticalItems.length > 0 && (
            <div className="bg-red-100 text-red-800 px-3 py-1 rounded-full text-sm font-medium flex items-center">
              <AlertTriangle className="w-4 h-4 mr-1" />
              {criticalItems.length} Critical
            </div>
          )}
          {lowStockItems.length > 0 && (
            <div className="bg-orange-100 text-orange-800 px-3 py-1 rounded-full text-sm font-medium flex items-center">
              <TrendingDown className="w-4 h-4 mr-1" />
              {lowStockItems.length} Low Stock
            </div>
          )}
        </div>
      </div>

      <div className="space-y-4">
        {inventory.map(item => {
          const status = getStockStatus(item);
          const percentage = (item.currentStock / item.maxCapacity) * 100;
          
          return (
            <div key={item.id} className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-3">
                  <Package className="w-5 h-5 text-gray-600" />
                  <div>
                    <h3 className="font-medium text-gray-800">{item.name}</h3>
                    <p className="text-sm text-gray-600">{item.category}</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className={`px-2 py-1 rounded text-xs font-medium ${
                    status.color === 'red' ? 'bg-red-100 text-red-800' :
                    status.color === 'orange' ? 'bg-orange-100 text-orange-800' :
                    status.color === 'yellow' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-green-100 text-green-800'
                  }`}>
                    {status.status}
                  </div>
                </div>
              </div>

              <div className="mb-2">
                <div className="flex justify-between text-sm text-gray-600 mb-1">
                  <span>{item.currentStock} {item.unit}</span>
                  <span>{percentage.toFixed(0)}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full ${
                      status.color === 'red' ? 'bg-red-500' :
                      status.color === 'orange' ? 'bg-orange-500' :
                      status.color === 'yellow' ? 'bg-yellow-500' :
                      'bg-green-500'
                    }`}
                    style={{ width: `${Math.min(percentage, 100)}%` }}
                  ></div>
                </div>
              </div>

              <div className="flex justify-between text-xs text-gray-500">
                <span>Min: {item.minThreshold} {item.unit}</span>
                <span>Max: {item.maxCapacity} {item.unit}</span>
              </div>

              {item.expiryDate && (
                <div className="flex items-center mt-2 text-xs text-gray-500">
                  <Calendar className="w-3 h-3 mr-1" />
                  Expires: {item.expiryDate.toLocaleDateString()}
                </div>
              )}

              <div className="text-xs text-gray-400 mt-1">
                Last updated: {item.lastUpdated.toLocaleString()}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default InventoryMonitor;