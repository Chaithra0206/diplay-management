import React from 'react';
import { Clock, User, AlertCircle } from 'lucide-react';
import { Patient } from '../types';

interface PatientQueueProps {
  patients: Patient[];
  department: string;
  currentToken: string;
}

const PatientQueue: React.FC<PatientQueueProps> = ({ 
  patients, 
  department, 
  currentToken 
}) => {
  const departmentPatients = patients
    .filter(p => p.department === department)
    .sort((a, b) => parseInt(a.tokenNumber.split('-')[1]) - parseInt(b.tokenNumber.split('-')[1]));

  const waitingPatients = departmentPatients.filter(p => p.status === 'waiting');
  const inProgressPatients = departmentPatients.filter(p => p.status === 'in-progress');

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold text-gray-800">{department} Queue</h2>
        <div className="bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-medium">
          Current: {currentToken}
        </div>
      </div>

      {/* In Progress */}
      {inProgressPatients.length > 0 && (
        <div className="mb-6">
          <h3 className="text-sm font-semibold text-gray-600 mb-2 flex items-center">
            <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></div>
            In Progress
          </h3>
          <div className="space-y-2">
            {inProgressPatients.map(patient => (
              <div key={patient.id} className="flex items-center justify-between p-3 bg-green-50 rounded-lg border-l-4 border-green-500">
                <div className="flex items-center space-x-3">
                  <User className="w-4 h-4 text-green-600" />
                  <div>
                    <span className="font-medium text-green-800">{patient.tokenNumber}</span>
                    <span className="text-sm text-green-600 ml-2">({patient.initials})</span>
                  </div>
                </div>
                {patient.priority === 'urgent' && (
                  <AlertCircle className="w-4 h-4 text-orange-500" />
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Waiting Queue */}
      <div>
        <h3 className="text-sm font-semibold text-gray-600 mb-2 flex items-center">
          <div className="w-2 h-2 bg-blue-500 rounded-full mr-2"></div>
          Waiting ({waitingPatients.length})
        </h3>
        <div className="space-y-2 max-h-64 overflow-y-auto">
          {waitingPatients.slice(0, 8).map((patient, index) => (
            <div key={patient.id} className={`flex items-center justify-between p-3 rounded-lg ${
              index < 3 ? 'bg-blue-50 border-l-4 border-blue-500' : 'bg-gray-50'
            }`}>
              <div className="flex items-center space-x-3">
                <div className="text-xs font-mono text-gray-500">
                  #{index + 1}
                </div>
                <User className="w-4 h-4 text-gray-600" />
                <div>
                  <span className="font-medium text-gray-800">{patient.tokenNumber}</span>
                  <span className="text-sm text-gray-600 ml-2">({patient.initials})</span>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                {patient.priority === 'urgent' && (
                  <AlertCircle className="w-4 h-4 text-orange-500" />
                )}
                <div className="flex items-center text-sm text-gray-500">
                  <Clock className="w-3 h-3 mr-1" />
                  {patient.estimatedWaitTime}m
                </div>
              </div>
            </div>
          ))}
          {waitingPatients.length > 8 && (
            <div className="text-center text-sm text-gray-500 py-2">
              +{waitingPatients.length - 8} more patients waiting
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PatientQueue;