import React from 'react';
import { Users, Clock, Activity, UserCheck } from 'lucide-react';
import { Department } from '../types';

interface DepartmentOverviewProps {
  departments: Department[];
}

const DepartmentOverview: React.FC<DepartmentOverviewProps> = ({ departments }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {departments.map(dept => (
        <div key={dept.id} className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-lg text-gray-800">{dept.name}</h3>
            <div className={`w-3 h-3 rounded-full ${
              dept.status === 'active' ? 'bg-green-500' : 
              dept.status === 'maintenance' ? 'bg-yellow-500' : 'bg-red-500'
            }`}></div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Activity className="w-4 h-4" />
                <span>Current Token</span>
              </div>
              <span className="font-mono font-bold text-blue-600">{dept.currentToken}</span>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Users className="w-4 h-4" />
                <span>Today's Total</span>
              </div>
              <span className="font-semibold">{dept.totalPatientsToday}</span>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Clock className="w-4 h-4" />
                <span>Avg Wait</span>
              </div>
              <span className="font-semibold">{dept.averageWaitTime}m</span>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <UserCheck className="w-4 h-4" />
                <span>Active Staff</span>
              </div>
              <span className="font-semibold">{dept.activeStaff}</span>
            </div>
          </div>

          <div className="mt-4 pt-4 border-t">
            <div className="text-xs text-gray-500 text-center">
              Status: <span className={`font-medium ${
                dept.status === 'active' ? 'text-green-600' : 
                dept.status === 'maintenance' ? 'text-yellow-600' : 'text-red-600'
              }`}>{dept.status.toUpperCase()}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default DepartmentOverview;