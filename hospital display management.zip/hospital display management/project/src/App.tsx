import React, { useState } from 'react';
import { Monitor, Shield, ToggleLeft, ToggleRight } from 'lucide-react';
import StaffDashboard from './components/StaffDashboard';
import PatientDisplay from './components/PatientDisplay';
import { useRealTimeData } from './hooks/useRealTimeData';

function App() {
  const [viewMode, setViewMode] = useState<'staff' | 'patient'>('staff');
  const { patients, departments } = useRealTimeData();

  return (
    <div className="min-h-screen">
      {/* View Toggle */}
      <div className="fixed top-4 left-4 z-40 bg-white rounded-lg shadow-lg p-2 flex items-center space-x-3">
        <div className="flex items-center space-x-2">
          <Shield className="w-4 h-4 text-gray-600" />
          <span className="text-sm font-medium">Staff</span>
        </div>
        <button
          onClick={() => setViewMode(viewMode === 'staff' ? 'patient' : 'staff')}
          className="focus:outline-none"
        >
          {viewMode === 'staff' ? (
            <ToggleLeft className="w-6 h-6 text-blue-600" />
          ) : (
            <ToggleRight className="w-6 h-6 text-blue-600" />
          )}
        </button>
        <div className="flex items-center space-x-2">
          <Monitor className="w-4 h-4 text-gray-600" />
          <span className="text-sm font-medium">Patient</span>
        </div>
      </div>

      {/* Main Content */}
      {viewMode === 'staff' ? (
        <StaffDashboard />
      ) : (
        <PatientDisplay patients={patients} departments={departments} />
      )}
    </div>
  );
}

export default App;