import { useState, useEffect } from 'react';
import { Patient, Department, InventoryItem, EmergencyAlert } from '../types';

// Simulated real-time data hook
export const useRealTimeData = () => {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [alerts, setAlerts] = useState<EmergencyAlert[]>([]);

  // Initialize data
  useEffect(() => {
    // Initialize departments
    setDepartments([
      {
        id: 'ot',
        name: 'Operation Theater',
        code: 'OT',
        currentToken: 'OT-15',
        totalPatientsToday: 23,
        averageWaitTime: 45,
        activeStaff: 8,
        status: 'active'
      },
      {
        id: 'cardiology',
        name: 'Cardiology',
        code: 'CARD',
        currentToken: 'C-42',
        totalPatientsToday: 67,
        averageWaitTime: 25,
        activeStaff: 4,
        status: 'active'
      },
      {
        id: 'pharmacy',
        name: 'Pharmacy',
        code: 'PHARM',
        currentToken: 'P-128',
        totalPatientsToday: 156,
        averageWaitTime: 8,
        activeStaff: 6,
        status: 'active'
      },
      {
        id: 'general',
        name: 'General Consultation',
        code: 'GEN',
        currentToken: 'G-89',
        totalPatientsToday: 124,
        averageWaitTime: 35,
        activeStaff: 12,
        status: 'active'
      }
    ]);

    // Initialize patients
    const initialPatients: Patient[] = [];
    const departments = ['OT', 'CARD', 'PHARM', 'GEN'];
    
    for (let i = 0; i < 50; i++) {
      const dept = departments[Math.floor(Math.random() * departments.length)];
      const tokenNum = Math.floor(Math.random() * 200) + 1;
      initialPatients.push({
        id: `patient-${i}`,
        tokenNumber: `${dept}-${tokenNum}`,
        initials: `${String.fromCharCode(65 + Math.floor(Math.random() * 26))}${String.fromCharCode(65 + Math.floor(Math.random() * 26))}`,
        department: dept,
        status: Math.random() > 0.7 ? 'in-progress' : 'waiting',
        estimatedWaitTime: Math.floor(Math.random() * 60) + 10,
        priority: Math.random() > 0.9 ? (Math.random() > 0.5 ? 'urgent' : 'emergency') : 'normal',
        checkedInAt: new Date(Date.now() - Math.random() * 4 * 60 * 60 * 1000)
      });
    }
    setPatients(initialPatients);

    // Initialize inventory
    setInventory([
      {
        id: 'paracetamol',
        name: 'Paracetamol 500mg',
        category: 'Analgesics',
        currentStock: 450,
        minThreshold: 100,
        maxCapacity: 1000,
        unit: 'tablets',
        lastUpdated: new Date(),
        supplier: 'MedSupply Co.',
        expiryDate: new Date(2025, 11, 15)
      },
      {
        id: 'insulin',
        name: 'Insulin Injection',
        category: 'Diabetes',
        currentStock: 45,
        minThreshold: 50,
        maxCapacity: 200,
        unit: 'vials',
        lastUpdated: new Date(),
        supplier: 'PharmaCorp',
        expiryDate: new Date(2025, 8, 20)
      },
      {
        id: 'antibiotics',
        name: 'Amoxicillin 250mg',
        category: 'Antibiotics',
        currentStock: 180,
        minThreshold: 80,
        maxCapacity: 500,
        unit: 'capsules',
        lastUpdated: new Date(),
        supplier: 'MedSupply Co.',
        expiryDate: new Date(2026, 2, 10)
      },
      {
        id: 'surgical-gloves',
        name: 'Surgical Gloves',
        category: 'Surgical Supplies',
        currentStock: 25,
        minThreshold: 50,
        maxCapacity: 500,
        unit: 'boxes',
        lastUpdated: new Date(),
        supplier: 'SurgicalPro Ltd.'
      }
    ]);
  }, []);

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      // Update patient queue occasionally
      if (Math.random() > 0.8) {
        setPatients(prev => {
          const updated = [...prev];
          const randomIndex = Math.floor(Math.random() * updated.length);
          if (updated[randomIndex]?.status === 'waiting') {
            updated[randomIndex].status = 'in-progress';
            updated[randomIndex].estimatedWaitTime = Math.max(0, updated[randomIndex].estimatedWaitTime - 5);
          }
          return updated;
        });
      }

      // Update department tokens occasionally
      if (Math.random() > 0.9) {
        setDepartments(prev => prev.map(dept => ({
          ...dept,
          currentToken: `${dept.code}-${parseInt(dept.currentToken.split('-')[1]) + 1}`,
          totalPatientsToday: dept.totalPatientsToday + (Math.random() > 0.5 ? 1 : 0)
        })));
      }

      // Simulate inventory updates
      if (Math.random() > 0.95) {
        setInventory(prev => prev.map(item => ({
          ...item,
          currentStock: Math.max(0, item.currentStock + (Math.random() > 0.5 ? -1 : 1)),
          lastUpdated: new Date()
        })));
      }
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const addEmergencyAlert = (alert: Omit<EmergencyAlert, 'id' | 'timestamp'>) => {
    const newAlert: EmergencyAlert = {
      ...alert,
      id: `alert-${Date.now()}`,
      timestamp: new Date()
    };
    setAlerts(prev => [newAlert, ...prev]);
    
    // Auto-dismiss alert after 5 minutes for non-critical alerts
    if (alert.priority !== 'critical') {
      setTimeout(() => {
        setAlerts(prev => prev.filter(a => a.id !== newAlert.id));
      }, 300000);
    }
  };

  const dismissAlert = (alertId: string) => {
    setAlerts(prev => prev.filter(alert => alert.id !== alertId));
  };

  // Patient management functions
  const addPatient = (department: string, initials: string, priority: 'normal' | 'urgent' | 'emergency' = 'normal') => {
    const dept = departments.find(d => d.code === department);
    if (!dept) return;

    // Get next token number for the department
    const deptPatients = patients.filter(p => p.department === department);
    const maxToken = Math.max(
      ...deptPatients.map(p => parseInt(p.tokenNumber.split('-')[1])),
      parseInt(dept.currentToken.split('-')[1])
    );
    const nextTokenNumber = maxToken + 1;

    const newPatient: Patient = {
      id: `patient-${Date.now()}`,
      tokenNumber: `${department}-${nextTokenNumber}`,
      initials: initials.toUpperCase(),
      department,
      status: 'waiting',
      estimatedWaitTime: dept.averageWaitTime,
      priority,
      checkedInAt: new Date()
    };

    setPatients(prev => [...prev, newPatient]);
    
    // Update department stats
    setDepartments(prev => prev.map(d => 
      d.code === department 
        ? { ...d, totalPatientsToday: d.totalPatientsToday + 1 }
        : d
    ));

    // Simulate patient display notification
    console.log(`✅ New patient added: ${newPatient.tokenNumber} (${newPatient.initials}) - Priority: ${priority.toUpperCase()}`);
  };

  const callNextToken = (department: string) => {
    const waitingPatients = patients
      .filter(p => p.department === department && p.status === 'waiting')
      .sort((a, b) => {
        // Priority patients first
        if (a.priority === 'emergency' && b.priority !== 'emergency') return -1;
        if (b.priority === 'emergency' && a.priority !== 'emergency') return 1;
        if (a.priority === 'urgent' && b.priority === 'normal') return -1;
        if (b.priority === 'urgent' && a.priority === 'normal') return 1;
        
        // Then by token number
        return parseInt(a.tokenNumber.split('-')[1]) - parseInt(b.tokenNumber.split('-')[1]);
      });

    if (waitingPatients.length === 0) return;

    const nextPatient = waitingPatients[0];
    
    // Update patient status
    setPatients(prev => prev.map(p => 
      p.id === nextPatient.id 
        ? { ...p, status: 'in-progress' as const }
        : p
    ));

    // Update department current token
    setDepartments(prev => prev.map(d => 
      d.code === department 
        ? { ...d, currentToken: nextPatient.tokenNumber }
        : d
    ));

    // Simulate patient display and audio announcement
    console.log(`🔊 CALLING NEXT PATIENT: ${nextPatient.tokenNumber} (${nextPatient.initials}) to ${department} - Priority: ${nextPatient.priority.toUpperCase()}`);
    console.log(`📺 Patient display updated: Now showing ${nextPatient.tokenNumber} as currently being served`);
  };

  const skipPatient = (patientId: string) => {
    const patient = patients.find(p => p.id === patientId);
    if (!patient) return;

    setPatients(prev => prev.map(p => 
      p.id === patientId 
        ? { ...p, estimatedWaitTime: p.estimatedWaitTime + 15 }
        : p
    ));

    console.log(`⏭️ Patient skipped: ${patient.tokenNumber} (${patient.initials}) - Wait time increased by 15 minutes`);
  };

  const removePatient = (patientId: string) => {
    const patient = patients.find(p => p.id === patientId);
    if (!patient) return;

    setPatients(prev => prev.filter(p => p.id !== patientId));
    console.log(`❌ Patient removed: ${patient.tokenNumber} (${patient.initials})`);
  };

  const completePatient = (patientId: string) => {
    const patient = patients.find(p => p.id === patientId);
    if (!patient) return;

    setPatients(prev => prev.map(p => 
      p.id === patientId 
        ? { ...p, status: 'completed' as const }
        : p
    ));

    console.log(`✅ Patient completed: ${patient.tokenNumber} (${patient.initials})`);
  };

  const callPatient = (patientId: string) => {
    const patient = patients.find(p => p.id === patientId);
    if (!patient) return;

    // Update patient status to in-progress
    setPatients(prev => prev.map(p => 
      p.id === patientId 
        ? { ...p, status: 'in-progress' as const }
        : p
    ));

    // Update department current token
    setDepartments(prev => prev.map(d => 
      d.code === patient.department 
        ? { ...d, currentToken: patient.tokenNumber }
        : d
    ));

    // Simulate patient display and audio announcement
    console.log(`🔊 CALLING PATIENT: ${patient.tokenNumber} (${patient.initials}) to ${patient.department} - Priority: ${patient.priority.toUpperCase()}`);
    console.log(`📺 Patient display updated: Now showing ${patient.tokenNumber} as currently being served with visual/audio alert`);
  };

  return {
    patients,
    departments,
    inventory,
    alerts,
    addEmergencyAlert,
    dismissAlert,
    addPatient,
    callNextToken,
    skipPatient,
    removePatient,
    completePatient,
    callPatient
  };
};